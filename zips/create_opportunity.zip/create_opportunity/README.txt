GPTfy Skill Package: create_opportunity
================================

Category : Opportunity
Apex     : OpportunityAgenticSkillsHandler (+ AgenticSkillsBase)
Prompt   : ccai__AI_Prompt__c Name = create_opportunity

WHAT IS IN THIS ZIP
-------------------
1. package.xml + force-app/     Apex classes required for this skill
2. seed.apex                    Creates the AI Prompt + links it to agent "GPTfy Agent"
3. sample-system-prompt.txt     Sample agent system prompt (paste/sync onto the agent)
4. README.txt                   This file

PREREQUISITES
-------------
- GPTfy managed package (ccai) installed
- Salesforce CLI (sf) authenticated to the target org
- A Data Extraction Mapping Id and an AI Connection (model) Id in THIS org

IMPORT STEPS
------------
1) Edit seed.apex — set DATA_MAPPING and AI_MODEL to Ids from your org.

   sf data query --query "SELECT Id, Name FROM ccai__AI_Data_Extraction_Mapping__c LIMIT 20" --target-org <alias>
   sf data query --query "SELECT Id, Name FROM ccai__AI_Connection__c LIMIT 20" --target-org <alias>

2) Deploy Apex (from the unzipped folder):

   sf project deploy start --manifest package.xml --target-org <alias>

3) Seed the prompt record + agent link:

   sf apex run --file seed.apex --target-org <alias>

4) Apply the system prompt to the agent (GPTfy UI, or your sync script).
   Use sample-system-prompt.txt as the starting agent instructions.
   If the agent already has a system prompt, merge this skill into the skills catalog section.

NOTES
-----
- Apex is shared per object. Deploying OpportunityAgenticSkillsHandler installs all methods in that class;
  this seed still creates ONLY the "create_opportunity" prompt record.
- Re-running seed.apex is safe: existing prompt Names are skipped; missing links are added.
- Mapping / Model Ids do not transfer between orgs.

Skill summary
-------------
Creates a new Opportunity. Use when the user explicitly asks to create or add an Opportunity. Three fields are mandatory: "Name", "StageName" and "CloseDate" (yyyy-MM-dd). Resolve any relative date expressions to yyyy-MM-dd BEFORE calling.
