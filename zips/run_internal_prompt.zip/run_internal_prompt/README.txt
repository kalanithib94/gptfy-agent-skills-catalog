GPTfy Skill Package: run_internal_prompt
================================

Category : Utility
Apex     : UtilityAgenticSkillsHandler (+ AgenticSkillsBase)
Prompt   : ccai__AI_Prompt__c Name = run_internal_prompt

WHAT IS IN THIS ZIP
-------------------
1. package.xml + force-app/     Apex classes required for this skill
2. seed.apex                    Creates the AI Prompt + links it to agent "GPTfy Agent"
3. sample-system-prompt.txt     Sample agent system prompt (paste/sync onto the agent)
4. README.txt                   This file

PREREQUISITES
-------------
- GPTfy managed package (ccai) installed
- Salesforce CLI (sf) authenticated to the target org
- A Data Extraction Mapping Id and an AI Connection (model) Id in THIS org

IMPORT STEPS
------------
1) Edit seed.apex — set DATA_MAPPING and AI_MODEL to Ids from your org.

   sf data query --query "SELECT Id, Name FROM ccai__AI_Data_Extraction_Mapping__c LIMIT 20" --target-org <alias>
   sf data query --query "SELECT Id, Name FROM ccai__AI_Connection__c LIMIT 20" --target-org <alias>

2) Deploy Apex (from the unzipped folder):

   sf project deploy start --manifest package.xml --target-org <alias>

3) Seed the prompt record + agent link:

   sf apex run --file seed.apex --target-org <alias>

4) Apply the system prompt to the agent (GPTfy UI, or your sync script).
   Use sample-system-prompt.txt as the starting agent instructions.
   If the agent already has a system prompt, merge this skill into the skills catalog section.

NOTES
-----
- Apex is shared per object. Deploying UtilityAgenticSkillsHandler installs all methods in that class;
  this seed still creates ONLY the "run_internal_prompt" prompt record.
- Re-running seed.apex is safe: existing prompt Names are skipped; missing links are added.
- Mapping / Model Ids do not transfer between orgs.

Skill summary
-------------
Invokes an internal GPTfy AI Prompt against a specific record and returns the LLM-generated narrative. This is the "Mixed Operation" skill — combines record context (DML) with an internal prompt to generate prose answers (deal overview, stakeholder map, meeting prep, executive summary, etc.). Use whenever the user asks an open-ended question against a specific record that is best answered by a configured GPTfy Prompt Request. The prompt_request_id MUST be a pre-configured GPTfy Prompt Request Id that exists in the org — never invent it.
