GPTfy Skill Package: fetch_account_details
================================

Category : Account
Apex     : AccountAgenticSkillsHandler (+ AgenticSkillsBase)
Prompt   : ccai__AI_Prompt__c Name = fetch_account_details

WHAT IS IN THIS ZIP
-------------------
1. package.xml + force-app/     Apex classes required for this skill
2. seed.apex                    Creates the AI Prompt + links it to agent "GPTfy Agent"
3. sample-system-prompt.txt     Sample agent system prompt (paste/sync onto the agent)
4. README.txt                   This file

PREREQUISITES
-------------
- GPTfy managed package (ccai) installed
- Salesforce CLI (sf) authenticated to the target org
- A Data Extraction Mapping Id and an AI Connection (model) Id in THIS org

IMPORT STEPS
------------
1) Edit seed.apex — set DATA_MAPPING and AI_MODEL to Ids from your org.

   sf data query --query "SELECT Id, Name FROM ccai__AI_Data_Extraction_Mapping__c LIMIT 20" --target-org <alias>
   sf data query --query "SELECT Id, Name FROM ccai__AI_Connection__c LIMIT 20" --target-org <alias>

2) Deploy Apex (from the unzipped folder):

   sf project deploy start --manifest package.xml --target-org <alias>

3) Seed the prompt record + agent link:

   sf apex run --file seed.apex --target-org <alias>

4) Apply the system prompt to the agent (GPTfy UI, or your sync script).
   Use sample-system-prompt.txt as the starting agent instructions.
   If the agent already has a system prompt, merge this skill into the skills catalog section.

NOTES
-----
- Apex is shared per object. Deploying AccountAgenticSkillsHandler installs all methods in that class;
  this seed still creates ONLY the "fetch_account_details" prompt record.
- Re-running seed.apex is safe: existing prompt Names are skipped; missing links are added.
- Mapping / Model Ids do not transfer between orgs.

Skill summary
-------------
Account detail JSON: pass account_id (preferred on 001 page) OR account_name. Name fuzzy: 1 match = full row; 2-5 = AMBIGUOUS_ACCOUNT_NAME + picker rows; 6+ = TOO_MANY_ACCOUNT_MATCHES. No Rating. Never pass an Id as account_name.
